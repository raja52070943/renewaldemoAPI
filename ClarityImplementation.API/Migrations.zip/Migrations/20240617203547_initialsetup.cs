﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ClarityImplementation.API.Migrations
{
    /// <inheritdoc />
    public partial class initialsetup : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
    name: "api_notification_logs",
    columns: table => new
    {
        notification_id = table.Column<int>(type: "int", nullable: false)
            .Annotation("SqlServer:Identity", "1, 1"),
        user_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
        destination_address = table.Column<string>(type: "nvarchar(max)", nullable: true),
        notification_source = table.Column<string>(type: "nvarchar(max)", nullable: true),
        notification_type = table.Column<string>(type: "nvarchar(max)", nullable: true),
        notification_category = table.Column<string>(type: "nvarchar(max)", nullable: true),
        notification_sub_category = table.Column<string>(type: "nvarchar(max)", nullable: true),
        notification_content = table.Column<string>(type: "nvarchar(max)", nullable: true),
        notification_sent_at = table.Column<DateTime>(type: "datetime2", nullable: true),
        created_at = table.Column<DateTime>(type: "datetime2", nullable: true),
        updated_at = table.Column<DateTime>(type: "datetime2", nullable: true),
        created_by = table.Column<string>(type: "nvarchar(max)", nullable: true),
        updated_by = table.Column<string>(type: "nvarchar(max)", nullable: true),
        notification_status = table.Column<string>(type: "nvarchar(max)", nullable: true),
        case_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
        case_owner_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
        notification_label = table.Column<string>(type: "nvarchar(max)", nullable: true),
        sf_task_id = table.Column<string>(type: "nvarchar(max)", nullable: true),
        mailbox_uid = table.Column<string>(type: "nvarchar(max)", nullable: true),
        mailbox_address = table.Column<string>(type: "nvarchar(max)", nullable: true),
        mailbox_folder_name = table.Column<string>(type: "nvarchar(max)", nullable: true)
    },
    constraints: table =>
    {
        table.PrimaryKey("PK_api_notification_logs", x => x.notification_id);
    });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
    name: "api_notification_logs");
        }
    }
}
