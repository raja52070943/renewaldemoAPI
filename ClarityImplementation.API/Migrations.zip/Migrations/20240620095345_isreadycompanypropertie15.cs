﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ClarityImplementation.API.Migrations
{
    /// <inheritdoc />
    public partial class isreadycompanypropertie15 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "CreatedOn",
                table: "Companies",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(2024, 6, 20, 5, 53, 45, 140, DateTimeKind.Local).AddTicks(8791),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldDefaultValue: new DateTime(2024, 6, 20, 4, 34, 19, 502, DateTimeKind.Local).AddTicks(8481));

            migrationBuilder.AddColumn<bool>(
                name: "IsReadyForProcessing",
                table: "Companies",
                type: "bit",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsReadyForProcessing",
                table: "Companies");

            migrationBuilder.AlterColumn<DateTime>(
                name: "CreatedOn",
                table: "Companies",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(2024, 6, 20, 4, 34, 19, 502, DateTimeKind.Local).AddTicks(8481),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldDefaultValue: new DateTime(2024, 6, 20, 5, 53, 45, 140, DateTimeKind.Local).AddTicks(8791));
        }
    }
}
