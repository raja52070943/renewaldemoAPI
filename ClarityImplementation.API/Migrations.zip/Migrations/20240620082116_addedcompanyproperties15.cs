﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ClarityImplementation.API.Migrations
{
    /// <inheritdoc />
    public partial class addedcompanyproperties15 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "CreatedOn",
                table: "Companies",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(2024, 6, 20, 4, 21, 15, 500, DateTimeKind.Local).AddTicks(5578),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldDefaultValue: new DateTime(2024, 6, 17, 16, 35, 47, 241, DateTimeKind.Local).AddTicks(4658));

            migrationBuilder.AddColumn<int>(
                name: "ClientAnnualRevenue",
                table: "Companies",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "IsUsedForTesting",
                table: "Companies",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "LastRolloutError",
                table: "Companies",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SalesRepName",
                table: "Companies",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ClientAnnualRevenue",
                table: "Companies");

            migrationBuilder.DropColumn(
                name: "IsUsedForTesting",
                table: "Companies");

            migrationBuilder.DropColumn(
                name: "LastRolloutError",
                table: "Companies");

            migrationBuilder.DropColumn(
                name: "SalesRepName",
                table: "Companies");

            migrationBuilder.AlterColumn<DateTime>(
                name: "CreatedOn",
                table: "Companies",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(2024, 6, 17, 16, 35, 47, 241, DateTimeKind.Local).AddTicks(4658),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldDefaultValue: new DateTime(2024, 6, 20, 4, 21, 15, 500, DateTimeKind.Local).AddTicks(5578));
        }
    }
}
